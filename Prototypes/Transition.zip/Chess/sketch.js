let startFEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"
let randomFEN = "bbrknnqr/pppppppp/8/8/8/8/PPPPPPPP/BBRKNNQR"
let newFEN = "rn1qkb1r/pp2pppp/2p2n2/5b2/P1pP3N/2N5/1P2PPPP/R1BQKB1R"

let clickedTime = 0
let currentTransition = [null, null]
let mouseBuffer = [false, false, false]
let menuDebounce = true
let decile, game, time
let mode = "menu"

let menuButtonStyle = `
	transition: background-color 0.5s, width 0.5s, opacity 0.5s, left 0.5s;
	font-family: kodeMono, Courier New, Arial, serif;
	-webkit-text-stroke: black 0.5vh;
	border-bottom-right-radius: 3vh;
	border-top-right-radius: 3vh;
	-webkit-touch-callout: none;
	position: absolute;
	padding-right: 2vw;
	text-align: right;
	font-weight: bold;
	user-select: none;
	font-size: 15vh;
	cursor: default;
	color: #E0E0E0;
	opacity: 0.9;
	height: 20vh;
` 

function preload() {
	// Pieces by Cburnett - Own work, CC BY-SA 3.0
    pieces = {
        "k": loadImage("Pieces/bKing.png"),
        "q": loadImage("Pieces/bQueen.png"),
        "r": loadImage("Pieces/bRook.png"),
    	"b": loadImage("Pieces/bBishop.png"),
        "n": loadImage("Pieces/bKnight.png"),
        "p": loadImage("Pieces/bPawn.png"),
        "K": loadImage("Pieces/wKing.png"),
        "Q": loadImage("Pieces/wQueen.png"),
        "R": loadImage("Pieces/wRook.png"),
        "B": loadImage("Pieces/wBishop.png"),
        "N": loadImage("Pieces/wKnight.png"),
        "P": loadImage("Pieces/wPawn.png")
    }
	sfx = {
		"check": loadSound("SFX/check.mp3"),
		"move": loadSound("SFX/move.mp3"),
		"hover": loadSound("SFX/menuHover.mp3"),
		"click1": loadSound("SFX/menuClick1.mp3"),
		"click2": loadSound("SFX/menuClick2.mp3"),
		"click3": loadSound("SFX/menuClick3.mp3"),
		"error": loadSound("SFX/error.mp3")
	}
	songs = {
		"checkmate": loadSound("Songs/checkmate.mp3")
	}
	kodeMono = loadFont("Font/KodeMono.ttf")
}

function setup() {
	songs["checkmate"].loop()
	createCanvas(windowWidth, windowHeight)
	textFont(kodeMono)
	game = new Chess(startFEN)

	backButton = createDiv("Back")
	backButton.style(menuButtonStyle + `
		-webkit-text-stroke: black 0.25vh;
		border-bottom-left-radius: 1vh;
		border-top-left-radius: 1vh;
		background-color: #4A4A4A;
		padding-left: 1vw;
		text-align: left;
		font-size: 8vh;
		height: 10vh;
		left: 100vw;
		width: 0vw;
		top: 5vh;
	`)
	buttons = {
		divs: {
			"top": createDiv("Play"),
			"middle": createDiv("Puzzles"),
			"bottom": createDiv("Credits"),
		},

		uColour: {
			"Play": "#C8C8C8",
			"Puzzles": "#969696",
			"Credits": "#646464",

			"Standard": "#64B5F6",
			"Chess960": "#1E88E5",
			"Atomic": "#1565C0",

			"Classic": "#FBC02D",
			"Rhythm": "#F9A825",
			"Solo": "#F57F17"
		},

		vColour: {
			"Play": "#3399FF",
			"Puzzles": "#FFA500",
			"Credits": "#884DFF",
			
			"Standard": "#0097A7",
			"Chess960": "#00838F",
			"Atomic": "#006064",

			"Classic": "#FF5722",
			"Rhythm": "#E64A19",
			"Solo": "#BF360C"
		},

		width: {
			"Play": 70,
			"Puzzles": 60,
			"Credits": 50,

			"Standard": 70,
			"Chess960": 60,
			"Atomic": 50,

			"Classic": 70,
			"Rhythm": 60,
			"Solo": 50
		},

		sound: {
			"Play": "click1",
			"Puzzles": "click2",
			"Credits": "click3"
		},

		mode: { // is this necessary?
			"Play": "game",
			"Puzzles": "puzzlesMenu",
			"Credits": "creditsMenu"
		},

		"Play": { // Menu after button clicked
			"top": "Standard",
			"middle": "Chess960",
			"bottom": "Atomic"
		},

		"Puzzles": {
			"top": "Classic",
			"middle": "Rhythm",
			"bottom": "Solo"
		}
	}

	for (let div in buttons.divs) {
		let text = buttons.divs[div].html()
		let properties = `background-color: ${buttons.uColour[text]}; width: ${buttons.width[text]}vw`
		buttons.divs[div].style(menuButtonStyle + properties)
		buttons.divs[div].class("p5Canvas")
	}

	for (let element of document.getElementsByClassName("p5Canvas")) {
		element.addEventListener("contextmenu", v => v.preventDefault())
	}
}

function draw() {
	resizeCanvas(windowWidth, windowHeight)
	clear()
	time = new Date().getTime()
	decile = min(windowWidth, windowHeight) / 10
	background(50)

	buttons.divs["top"].position(0, windowHeight * 0.2)
	buttons.divs["middle"].position(0, windowHeight * 0.45)
	buttons.divs["bottom"].position(0, windowHeight * 0.7)
	game.draw()


	for (let div in buttons.divs) {
		let text = buttons.divs[div].html()
		buttons.divs[div].mouseOver(mouseHover)
		buttons.divs[div].mouseOut(mouseNotHover)
		buttons.divs[div].mousePressed(mouseClickedElement)
	}
	backButton.mouseOver(mouseHover)
	backButton.mouseOut(mouseNotHover)
	backButton.mousePressed(mouseClickedElement)

	transition(clickedTime, 1500, ...currentTransition)
}

class Chess { // Main Section of Code
	constructor(fen) {
		this.boardHistory = [this.initiateBoard(fen)]
		this.bitboards = this.getBitboards(fen)
		this.board = this.initiateBoard(fen)
		this.promoSquare = [false, false]
		this.canCastle = [true, true, true, true]
		this.highlightSquares = []
		this.arrowSquares = []
		this.moveHistory = []
		this.mode = "board"
		this.turn = true
		this.flip = true
		this.move = 0
		// this.rookStartX = [this.bitboards["R"][0][0], this.bitboards["R"][1][0]]
	}

	initiateBoard(fen) {
		let bufferArr = []
		let boardArr = []
		for (let char of fen) {
			if (char === "/") {
				boardArr.push([...bufferArr])
				bufferArr = []
			} else if (isNaN(Number(char))) {
				bufferArr.push(char)
			} else {
				for (let i = 0; i < Number(char); i++) {
					bufferArr.push("#")
				}
			}
		}
		boardArr.push([...bufferArr])
		return boardArr
	}

	getBitboards(fen) {
		let bitboards = Object.fromEntries(Array.from("rnbqkpRNBQKP").map(v => [v, []]))
		let x = 1; let y = 1
		for (let char of fen) {
			if (char === "/") {x = 1; y++
			} else if (isNaN(Number(char))) {
				bitboards[char].push([x, y]); x++
			} else {x += Number(char)}
		} return bitboards
	}

	getNotation(x, y) {return `${String.fromCharCode(96+x)}${9-y}`}

	inBounds(x, y) {return max(x, y) < 9 && min(x, y) > 0}

	getColour(piece) {return piece === piece.toUpperCase()}

	copyBoard(board) {
		let copy = []
		for (let v of board) {
			copy.push([...v])
		} return copy
	}

	copyBitboard(bitboard) {
		let copy = []
		for (let v in bitboard) {
			copy[v] = [...bitboard[v]]
		} return copy
	}

	tween(x1, y1, x2, y2) {
		let xIncre = x2-x1 ? floor((x2-x1) / abs(x2-x1)) : 0
		let yIncre = y2-y1 ? floor((y2-y1) / abs(y2-y1)) : 0
		let tweenSquares = []

		while (x1 !== x2 - xIncre || y1 !== y2 - yIncre) {
			x1 += xIncre; y1 += yIncre
			tweenSquares.push([x1, y1])
		} return tweenSquares
	}

	////////// Front End - User Interface //////////

	draw() { // Where it all happens...
		// this.highlightSquares = this.bitboards["P"]
		push()
		stroke(0, 0)
		this.drawShadow()
		this.drawBoard()
		this.drawHighlightSquares()
		this.drawClickedSquares()
		this.drawPosFromBoard()
		this.showLegalMoves()
		this.drawArrowSquares()
		if (this.mode === "promo") {this.promotionUI()}
		pop()
	}

	drawBoard() {
		for (let x = 1; x <= 8; x++) {
			for (let y = 1; y <= 8; y++) {
				let rgb = (x+y) % 2 !== 0 ? [100, 50, 175] : [200, 150, 255]
				fill(...rgb)
				square((x*decile), (y*decile), decile)
			}
		}	
	}

	drawShadow() {
		push()
		fill(0, 200)
		rectMode(CORNER)
		square(decile*1.125, decile*1.125, decile*8)
		pop()
	}

	drawHighlightSquares() {
		fill(235, 64, 52, 200)
		for (let [x, y] of this.highlightSquares) {
			if (!this.flip) {[x, y] = [9-x, 9-y]}
			square(x*decile, y*decile, decile)
		}
	}

	drawClickedSquares() {
		fill(173, 163, 83, 200)
		if (mouseBuffer[2] === true || (mouseIsPressed === true && mouseButton === LEFT) && mouseBuffer[0]) {
			if (this.flip) {square(mouseBuffer[0] * decile, mouseBuffer[1] * decile, decile)}
			else {square((9 - mouseBuffer[0]) * decile, (9 - mouseBuffer[1]) * decile, decile)}
		}
	}

	drawPosFromBoard() {
		let board = this.boardHistory[this.move]
		let ghostX = false
		let ghostY = false
		for (let x = 1; x <= 8; x++) {
			for (let y = 1; y <= 8; y++) {
				let arrX = this.flip ? y-1 : 8-y
				let arrY = this.flip ? x-1 : 8-x
				if (board[arrX][arrY] !== "#") {
					if ([LEFT, true].includes(mouseBuffer[2]) && arrY+1 === mouseBuffer[0] && arrX+1 === mouseBuffer[1] && mouseIsPressed) {
						ghostX = arrX
						ghostY = arrY
					} else {
						image(pieces[board[arrX][arrY]], x*decile, y*decile, decile, decile)					
					}
				}
			}
		} if (ghostX !== false && ghostY !== false) {
			push()
			imageMode(CENTER)
			image(pieces[board[ghostX][ghostY]], mouseX, mouseY, decile, decile)
			pop()	
		}
	}

	drawArrow(x1, y1, x2, y2, ghost=false) {
		if (!this.flip && !ghost) {[x1, y1, x2, y2] = [10-x1, 10-y1, 10-x2, 10-y2]}
		else if (!this.flip && ghost) {[x1, y1] = [10-x1, 10-y1]}
		let hypotenuse = dist(x1, y1, x2, y2)
		let angle = atan((y1-y2) / (x1-x2))
		let xAvg = (x1+x2)/2
		let yAvg = (y1+y2)/2
	
		circle(x2 * decile, y2 * decile, decile/3)
		circle(x2 * decile, y2 * decile, decile/2)
	
		push()
		translate(xAvg * decile, yAvg * decile)
		rotate(angle)
		translate(-xAvg * decile, -yAvg * decile)
		rect(xAvg * decile, yAvg * decile, hypotenuse * decile + decile/4, decile/4, decile/8)
		pop()
	}

	drawArrowSquares() {
		fill(235, 64, 52, 200)
		rectMode(CENTER)
		for (let [x1, y1, x2, y2] of this.arrowSquares) {
			this.drawArrow(x1, y1, x2, y2)
		}
		if (mouseBuffer[2] === RIGHT && mouseIsPressed === true && mouseButton === RIGHT && mouseBuffer[0]) {
			this.drawArrow(mouseBuffer[0]+0.5, mouseBuffer[1]+0.5, mouseX/decile, mouseY/decile, true)
		}
	}

	promotionUI() {
		let queen = !this.turn ? "Q" : "q"
		let rook = !this.turn ? "R" : "r"
		let knight = !this.turn ? "N" : "n"
		let bishop = !this.turn ? "B" : "b"
		push()
		imageMode(CENTER)
		fill(66, 135, 245, 200)
		rect(5*decile, 5*decile, 2.5*decile, 2.5*decile, 0.5*decile)
		pop()
		image(pieces[queen], 4*decile, 4*decile, decile, decile)
		image(pieces[rook], 5*decile, 4*decile, decile, decile)
		image(pieces[knight], 4*decile, 5*decile, decile, decile)
		image(pieces[bishop], 5*decile, 5*decile, decile, decile)
	}

	////////// Back End - Move Validation //////////

	updateAttributes(move) {
		this.board = move[0]
		this.boardHistory.push(move[0])
		this.canCastle = move[1]
		this.bitboards = move[2]
		this.moveHistory.push(move[3])
		this.move = this.boardHistory.length - 1
		this.turn = !this.turn
	}

	showLegalMoves() {
		if ((mouseBuffer[2] === true || (mouseIsPressed === true && mouseButton === LEFT) && mouseBuffer[0]) && this.mode === "board") {
			let target = this.board[mouseBuffer[1]-1][mouseBuffer[0]-1]
			if ([LEFT, true].includes(mouseBuffer[2]) && (this.getColour(target)) === this.turn) {
				push()
				fill(66, 135, 245, 100)
				for (let [x, y] of this.getLegalMoves(mouseBuffer[0], mouseBuffer[1])) {
					if (!this.flip) {[x, y] = [9-x, 9-y]}
					circle((x + 0.5) * decile, (y + 0.5) * decile, decile/3)
				} pop()
			}
		}
	}

	getHorizontalMoves(x1, y1) {
		let validMoves = []
		let colour = this.getColour(this.board[y1-1][x1-1])
		let x; let y
		for (let axis = 0; axis <= 1; axis++) {
			axis = Boolean(axis)
			for (let i = -1; i <= 1; i += 2) {
				x = axis ? i : 0
				y = !axis ? i : 0
				while (this.inBounds(x1+x, y1+y)) {
					let target = this.board[y1+y-1][x1+x-1]
					if (target === "#") {
						validMoves.push([x1+x, y1+y]) // Empty Square
					} else if (this.getColour(target) !== colour) {
						validMoves.push([x1+x, y1+y]) // Enemy Piece
						break
					} else { // Friendly Piece
						break
					}
					x += axis ? i : 0
					y += !axis ? i : 0
				}
			}
		}
		return validMoves
	}
	
	getDiagonalMoves(x1, y1) {
		let validMoves = []
		let colour = this.getColour(this.board[y1-1][x1-1])
		let x; let y
		for (let i = -1; i <= 1; i += 2) {
			for (let j = -1; j <= 1; j += 2) {
				x = i; y = j
				while (this.inBounds(x1+x, y1+y)) {
					let target = this.board[y1+y-1][x1+x-1]
					if (target === "#") {
						validMoves.push([x1+x, y1+y]) // Empty Square
					} else if (this.getColour(target) !== colour) {
						validMoves.push([x1+x, y1+y]) // Enemy Piece
						break
					} else { // Friendly Piece
						break
					}
					x += i; y += j
				}
			}
		}
		return validMoves
	}

	getLegalMoves(x1, y1) {
		let piece = this.board[y1 - 1][x1 - 1]
		let colour = this.getColour(piece)
		let pseudoLegalMoves = []
		let legalMoves = []
		switch(piece.toUpperCase()) {
			case "P":
				let double = colour ? 7 : 2
				let dir = colour ? -1 : 1
				if (this.inBounds(x1, y1 + dir) && this.board[y1+dir-1][x1-1] === "#") { // Normal Forwards Moves
					pseudoLegalMoves.push([x1, y1 + dir, false])
					if (y1 === double && this.board[y1+(2*dir)-1][x1-1] === "#") { // Double Move
						pseudoLegalMoves.push([x1, y1 + (2 * dir), false])
					}
				}

				for (let i = -1; i <= 1; i += 2) { // Capture Moves
					let target = this.board[y1+dir-1][x1+i-1]
					let enPassant = this.getNotation(x1+i, 9-(double)) + this.getNotation(x1+i, 9-(double+2*dir))
					if (this.inBounds(x1+i, y1+dir) && this.getColour(target) !== colour && target !== "#") {
						pseudoLegalMoves.push([x1 + i, y1 + dir, false])
					} else if (this.moveHistory[this.moveHistory.length-1] === enPassant && y1 === double+(3*dir)) {
						pseudoLegalMoves.push([x1 + i, y1 + dir, true])
					}
				}
				break
	
			case "N":
				for (let [x, y] of [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]]) {
					if (this.inBounds(x1+x, y1+y)) {
						let target = this.board[y1+y-1][x1+x-1]
						if (target === "#") { // Normal move
							pseudoLegalMoves.push([x1+x, y1+y])
						} else if (this.getColour(target) !== colour) { // Capture
							pseudoLegalMoves.push([x1+x, y1+y])
						}
					}
				}
				break
	
			case "B":
				pseudoLegalMoves = this.getDiagonalMoves(x1, y1)
				break
			
			case "R":
				pseudoLegalMoves = this.getHorizontalMoves(x1, y1)
				break
			
			case "Q":
				pseudoLegalMoves = this.getDiagonalMoves(x1, y1).concat(this.getHorizontalMoves(x1, y1))
				break
	
			case "K":
				for (let i = -1; i <= 1; i++) {
					for (let j = -1; j <= 1; j++) {
						if (this.inBounds(x1+i, y1+j)) {
							let target = this.board[y1+j-1][x1+i-1]
							if ((i !== 0 || j !== 0) && (this.getColour(target) !== colour || target === "#")) {
								pseudoLegalMoves.push([x1+i, y1+j])
							}
						}
					}
				}
				if (colour) { // Checks that every square between the king and rook is empty; AMEND FOR CHESS960 // || v[0] === this.rookStartX[0] || v[0] === this.bitboards["K"][0][0])) {
					if (this.canCastle[0] && this.tween(6, 8, 1, 8).every(v => this.board[v[1]-1][v[0]-1] === "#" && !this.isCheck(v[0], v[1], colour, this.bitboards, this.board))) {
						pseudoLegalMoves.push([x1-2, y1]) // Check if the player is castling through check, NOTE THAT THE CASTLING THROUGH CHECK BIT IS HARDCODED
					}
					if (this.canCastle[1] && this.tween(4, 8, 8, 8).every(v => this.board[v[1]-1][v[0]-1] === "#" && !this.isCheck(v[0], v[1], colour, this.bitboards, this.board))) {
						pseudoLegalMoves.push([x1+2, y1])
					}
				} else {
					if (this.canCastle[2] && this.tween(6, 1, 1, 1).every(v => this.board[v[1]-1][v[0]-1] === "#" && !this.isCheck(v[0], v[1], colour, this.bitboards, this.board))) {
						pseudoLegalMoves.push([x1-2, y1])
					}
					if (this.canCastle[3] && this.tween(4, 1, 8, 1).every(v => this.board[v[1]-1][v[0]-1] === "#" && !this.isCheck(v[0], v[1], colour, this.bitboards, this.board))) {
						pseudoLegalMoves.push([x1+2, y1])
					}
				}
				break
		}

		for (let v of pseudoLegalMoves) { // Final Move Validation
			let newBoard = this.handleMove(x1, y1, v[0], v[1], piece, this.copyBitboard(this.bitboards), this.copyBoard(this.board), [...this.canCastle], true)
			if (!this.isCheck(...newBoard[2][this.turn ? "K" : "k"][0], colour, newBoard[2], newBoard[0])) {
				legalMoves.push([v[0], v[1]])
			}
		} return legalMoves
	}

	handleMove(x1, y1, x2, y2, piece, locator, activeBoard, castleArr, query=false) {
		let moves = query ? [[x2, y2]] : this.getLegalMoves(x1, y1)
		let colour = this.getColour(piece)
		let notation = piece.toUpperCase() === "P" ? "" : piece.toUpperCase()
	
		if (moves.some(v => v[0] === x2 && v[1] === y2) && this.mode === "board") { // Valid Moves
			if (!query) {sfx["move"].play()}
			notation += this.getNotation(x1, y1)
			if (activeBoard[y2-1][x2-1] !== "#") {notation += "x"}
	
			let capturedPiece = activeBoard[y2-1][x2-1]
			if (capturedPiece !== "#") {
				locator[capturedPiece] = locator[capturedPiece].filter(v => v[0] !== x2 || v[1] !== y2)
			} locator[piece][locator[piece].findIndex(v => v[0] === x1 && v[1] === y1)] = [x2, y2]
	
			activeBoard[y2-1][x2-1] = activeBoard[y1-1][x1-1]
			activeBoard[y1-1][x1-1] = "#"
			if (piece.toUpperCase() === "P") { // Pawn Special Cases
				if (y2 === (colour ? 1 : 8)) { // Promotion
					if (!query) {
						this.mode = "promo" // change piece promotion later or smth bozo <---------------- Important; temporary fix
						this.promoSquare = [x2, y2]
						locator[piece] = locator[piece].filter(v => v[0] !== x2 || v[1] !== y2)
					}
				} else if (abs(x2-x1) === 1 && capturedPiece === "#") { // En Passant
					notation += "x"
					let capturedPawn = this.getColour(activeBoard[y1-1][x2-1]) ? "P" : "p"
					locator[capturedPawn] = locator[capturedPawn].filter(v => v[0] !== x2 || v[1] !== y1)
					activeBoard[y1-1][x2-1] = "#"
				}
			}
	
			notation += this.getNotation(x2, y2)
	
			if (piece.toUpperCase() === "K") { // King Special Cases
				if (colour) {
					castleArr[0] = false
					castleArr[1] = false
				} else {
					castleArr[2] = false
					castleArr[3] = false
				}
				if (abs(x1-x2) === 2) { // Castling - FIX IN CHESS960
					let rookNewX = x1-x2 > 0 ? 4 : 6
					let rookOldX = x1-x2 > 0 ? 1 : 8 // Here these vals need to be changed to rookStartX
					let rook = colour ? "R" : "r"
					let rookY = colour ? 8 : 1

					locator[rook][locator[rook].findIndex(v => v[0] === rookOldX && v[1] === rookY)] = [rookNewX, rookY]
					notation = x1-x2 > 0 ? "O-O-O" : "O-O"
					activeBoard[y2-1][rookNewX-1] = rook
					activeBoard[y2-1][rookOldX-1] = "#"
				}
			}
	
			if ((x1 === 1 && y1 === 1) || (x2 === 1 && y2 === 1)) { // Change this for chess960 too
				castleArr[2] = false
			} else if ((x1 === 1 && y1 === 8) || (x2 === 1 && y2 === 8)) {
				castleArr[0] = false
			} else if ((x1 === 8 && y1 === 1) || (x2 === 8 && y2 === 1)) {
				castleArr[3] = false
			} else if ((x1 === 8 && y1 === 8) || (x2 === 8 && y2 === 8)) {
				castleArr[1] = false
			}
			if (this.isCheck(...locator[this.turn ? "k" : "K"][0], !this.turn, locator, this.board)) {
				notation += "+"; if (!query) {sfx["check"].play()}
			} return [activeBoard, castleArr, locator, notation]
		} return false
	}

	isCheck(x1, y1, colour, locator, activeBoard) {
		let opposingKing = locator[colour ? "k" : "K"][0]
		if (max(abs(x1-opposingKing[0]), abs(y1-opposingKing[1])) === 1) {
			return true // Check by King
		}

		for (let [x, y] of locator[colour ? "q" : "Q"]) {
			if ([x1-x, y1-y].some(v => v === 0) || abs(x1-x) === abs(y1-y)) {
				if (this.tween(x, y, x1, y1).every(v => activeBoard[v[1]-1][v[0]-1] === "#")) {
					return true // Check by Queen
				}
			}
		}

		for (let [x, y] of locator[colour ? "r" : "R"]) {
			if ([x1-x, y1-y].some(v => v === 0)) {
				if (this.tween(x, y, x1, y1).every(v => activeBoard[v[1]-1][v[0]-1] === "#")) {
					return true // Check by Rook
				}
			}
		}

		for (let [x, y] of locator[colour ? "b" : "B"]) {
			if (abs(x1-x) === abs(y1-y)) {
				if (this.tween(x, y, x1, y1).every(v => activeBoard[v[1]-1][v[0]-1] === "#")) {
					return true // Check by Bishop
				}
			}
		}

		for (let [x, y] of locator[colour ? "n" : "N"]) {
			if ([abs(x1-x), abs(y1-y)].sort().join("") === [1, 2].join("")) {
				return true // Check by Knight
			}
		}

		for (let [x, y] of locator[colour ? "p" : "P"]) {
			if (abs(x1-x) === 1 && y1 === y + (colour ? 1 : -1)) {
				return true // Check by Pawn
			}
		} return false
	}
}

function mouseHover() {
	if (menuDebounce) {
		if (this.html() === "Back") {
			if (buttons.divs["top"].html() !== "Play") {
				sfx["hover"].play()
				this.style("width: 17vw; left: 82vw; background-color: #F44336")
			}
		} else {
			sfx["hover"].play()
			this.style(`width: ${buttons.width[this.html()] + 10}vw; background-color: ${buttons.vColour[this.html()]}`)
		}
	}
}

function mouseNotHover() {
	if (menuDebounce) {
		if (this.html() === "Back") {
			this.style("width: 14vw; left: 85vw; background-color: #4A4A4A")
		} else {
			this.style(`width: ${buttons.width[this.html()]}vw; background-color: ${buttons.uColour[this.html()]}`)
		}
	}
}

function mouseClickedElement() {
	let clickedButton = this.html()
	if (menuDebounce) {
		menuDebounce = false

		if (clickedButton === "Back") { ///// If back button pressed
			mode = "menu"
			if (buttons.divs["top"].html() !== "Play") {
				let prevButtons
				for (let div in buttons.divs) {
					buttons.divs[div].style("opacity: 0; width: 0vw")
				}

				switch (buttons.divs["top"].html()) {
					case "Standard":
					case "Classic": // Remove back button
						backButton.style("opacity: 0; background-color: #4A4A4A; width: 0vw; left: 100vw")
						prevButtons = {
							"top": "Play",
							"middle": "Puzzles",
							"bottom": "Credits"
						}; break
				}


				setTimeout(() => {
					menuDebounce = true
					for (let v of ["top", "middle", "bottom"]) {
						let newText = prevButtons[v]
						buttons.divs[v].html(newText)
						buttons.divs[v].style(`opacity: 0.9; background-color: ${buttons.uColour[newText]}; width: ${buttons.width[newText]}vw`)
					}
				}, 750)
			} else {menuDebounce = true}




		} else if (["Play", "Puzzles"].includes(clickedButton)) { // every other button
			for (let div in buttons.divs) {
				buttons.divs[div].style("opacity: 0; width: 0vw")
				sfx[buttons.sound[this.html()]].play()

				setTimeout(() => {
					menuDebounce = true // Bring back back button
					backButton.style("width: 14vw; left: 85vw; opacity: 0.9; background-color: #4A4A4A")
					for (let v of ["top", "middle", "bottom"]) {
						let newText = buttons[clickedButton][v]
						buttons.divs[v].html(newText)
						buttons.divs[v].style(`opacity: 0.9; background-color: ${buttons.uColour[newText]}; width: ${buttons.width[newText]}vw`)
					}			
				}, 750)
			}
		} else if (clickedButton === "Standard") { ///// Standard Gamemode /////
			clickedTime = time
			currentTransition = ["shutter", "bounce"]
			backButton.style("opacity: 0; background-color: #4A4A4A; width: 0vw; left: 100vw")
			for (let v of ["top", "middle", "bottom"]) {
				let newText = buttons.divs[v].html()
				buttons.divs[v].html(newText)
				buttons.divs[v].style(`opacity: 0; background-color: ${buttons.uColour[newText]}; width: 0vw`)
			}
			
			setTimeout(() => {
				mode = "game"
				clickedTime = time
				currentTransition = ["part", "sine"]
				
				setTimeout(() => {
					menuDebounce = true
					currentTransition = [null, null]
					backButton.style("width: 14vw; left: 85vw; opacity: 0.9; background-color: #4A4A4A")
				}, 2000)
			}, 2000)
		} else { // In progress gamemodes
			menuDebounce = true
			sfx["error"].play()
		}
	}
}

function transition(start, duration, type, style="linear") {
	push()
	let col = 0
	fill(col)
	stroke(0, 0)
	let t = factor(start, duration, style)
	switch (type) {
		////////// Transition In //////////
		case "ribbon":
			let slide = lerp(0, max(windowWidth, windowHeight) + min(windowWidth, windowHeight)/2, t)
			triangle(0, 0, 0, slide, slide, 0)
			triangle(0, windowHeight, 0, windowHeight - slide, slide, windowHeight)
			break

		case "shutter":
			triangle(0, 0, lerp(0, windowWidth, t), 0, 0, lerp(0, windowHeight, t))
			triangle(windowWidth, windowHeight, windowWidth, lerp(windowHeight, 0, t), lerp(windowWidth, 0, t), windowHeight)
			push(); stroke(col)
			if (t === 1) {line(0, windowHeight, windowWidth, 0)}
			pop()
			break

		case "drop":
			rect(0, 0, windowWidth, lerp(0, windowHeight, t))
			break

		case "slide":
			rect(0, 0, lerp(0, windowWidth, t), windowHeight)
			break

		////////// Transition Out //////////
		case "pull":
			triangle(lerp(0, windowWidth, t), lerp(0, windowHeight, t), 0, windowHeight, windowWidth, windowHeight)
			triangle(windowWidth, windowHeight, windowWidth, 0, lerp(0, windowWidth, t), lerp(0, windowHeight, t))
			push()
			stroke(col)
			line(lerp(0, windowWidth, t), lerp(0, windowHeight, t), windowWidth, windowHeight)
			pop()
			break

		case "lift":
			rect(0, 0, windowWidth, lerp(windowHeight, 0, t))
			break

		case "part":
			rect(0, 0, lerp(windowWidth/2, 0, t), windowHeight)
			rect(windowWidth, 0, lerp(-windowWidth/2, 0, t), windowHeight)
			break
	} pop()
}

function factor(start, duration, style="linear") {
	let x = min(1, (time - start) / duration)
	switch (style) {
		case "sine":
			return sin(HALF_PI * x)

		case "circular":
			return sqrt(2*x - x**2)

		case "exponential":
			return 1000 ** (x-1)

		case "elastic":
			return 1 - (x - 1)**2 * cos(7*x)

		case "bounce":
			return 1 - (x - 1)**2 * abs(cos(7*x))
		
		case "linear":
			return x

		default:
			return x**style
	}
}

function printHistory() {
	let moves = document.createElement("textarea")
	let moveList = []
	for (let i = 0; i < game.moveHistory.length; i += 2) {
		moveList.push(`${floor(i/2)+1}. ${game.moveHistory.slice(i, i + 2).join(" ")}`)
	}
	document.body.appendChild(moves)
	console.log(moveList.join("     "))
	moves.value = moveList.join("     ")
	moves.select()
	document.execCommand("copy")
	moves.remove()
}

function getRankandFileFromMouse(x, y) {
	if (min(x,y) > decile && max(x,y) < 9 * decile) {
		let rank = floor(x/decile)
		let file = floor(y/decile)
		if (!game.flip) {rank = 9 - rank; file = 9 - file}
		return [rank, file]
	}
	return [false, false]
}

function mousePressed() {
	[rank, file] = getRankandFileFromMouse(mouseX, mouseY)
	if (mouseButton === LEFT) {
		game.highlightSquares = []; game.arrowSquares = []; game.move = game.boardHistory.length - 1
		if (game.mode === "promo") { // Promotion
			if (min(rank, file) >= 4 && max(rank, file) <= 5) {
				let piece
				if (rank === 4 && file === 4) {
					piece = !game.turn ? "Q" : "q"
				} else if (rank === 5 && file === 4) {
					piece = !game.turn ? "R" : "r"
				} else if (rank === 4 && file === 5) {
					piece = !game.turn ? "N" : "n"
				} else if (rank === 5 && file === 5) {
					piece = !game.turn ? "B" : "b"
				} // Add promotion check here
				game.bitboards[piece].push([game.promoSquare[0], game.promoSquare[1]])
				game.board[game.promoSquare[1]-1][game.promoSquare[0]-1] = piece
				game.boardHistory[game.boardHistory.length-1][game.promoSquare[1]-1][game.promoSquare[0]-1] = piece
				game.moveHistory[game.moveHistory.length-1] += "=" + piece.toUpperCase()
				if (game.isCheck(...game.bitboards[!game.turn ? "k" : "K"][0], game.turn, game.bitboards, game.board)) {
					game.moveHistory[game.moveHistory.length-1] += "+"
				} game.mode = "board"
			}
		}
	}

	if (rank && file && mode === "game") {
		if (mouseBuffer[2] === true && mouseButton === LEFT) {
			if ((mouseBuffer[0] !== rank || mouseBuffer[1] !== file) && mouseButton === LEFT) {
				let piece = game.board[mouseBuffer[1] - 1][mouseBuffer[0] - 1]
				let move = game.handleMove(mouseBuffer[0], mouseBuffer[1], rank, file, piece, game.copyBitboard(game.bitboards), game.copyBoard(game.board), [...game.canCastle])
				if (move) {game.updateAttributes(move)}
			} mouseBuffer = [false, false, false]
			
		} else if (mouseButton !== LEFT || game.board[file-1][rank-1] !== "#") {
			mouseBuffer = [rank, file, mouseButton]
		} else {mouseBuffer = [false, false, false]}
	} else {mouseBuffer = [false, false, false]}
}

function mouseReleased() {
	[rank, file] = getRankandFileFromMouse(mouseX, mouseY)
	if (mouseBuffer.join("") === [rank, file, RIGHT].join("") && rank && file) { // Highlight Squares
		if (game.highlightSquares.every(arr => arr.join("") !== [rank, file].join(""))) {
			game.highlightSquares.push([rank, file])
		} else {
			game.highlightSquares = game.highlightSquares.filter(v => v.join("") !== [rank, file].join(""))
		}
	} else if (mouseBuffer[2] === RIGHT && mouseBuffer[0] && mouseBuffer[1] && rank && file) { // Arrow Squares
		if (game.arrowSquares.every(arr => arr.join("") !== [mouseBuffer[0]+0.5, mouseBuffer[1]+0.5, rank+0.5, file+0.5].join(""))) {
			game.arrowSquares.push([mouseBuffer[0]+0.5, mouseBuffer[1]+0.5, rank+0.5, file+0.5])
		} else {
			game.arrowSquares = game.arrowSquares.filter(v => v.join("") !== [mouseBuffer[0]+0.5, mouseBuffer[1]+0.5, rank+0.5, file+0.5].join(""))
		}
	} else if (mouseBuffer[2] === LEFT && (mouseBuffer[0] !== rank || mouseBuffer[1] !== file)) { // Handle Move
		let piece = game.board[mouseBuffer[1] - 1][mouseBuffer[0] - 1]
		if (game.getColour(piece) === game.turn && piece !== "#") {
			let move = game.handleMove(mouseBuffer[0], mouseBuffer[1], rank, file, piece, game.copyBitboard(game.bitboards), game.copyBoard(game.board), [...game.canCastle])
			if (move) {game.updateAttributes(move)}
		}
	} else if (mouseBuffer[2] === LEFT && (mouseBuffer[0] === rank && mouseBuffer[1] === file)) { // Possible Move
		let piece = game.board[file - 1][rank - 1]
		if (game.getColour(piece) === game.turn && piece !== "#") {
			mouseBuffer[2] = true
		}
	}
}

function keyPressed() {
	switch (key) {
		case "x":
			game.flip = !game.flip
			break

		case "r":
			game = new Chess(startFEN)
			break

		case "q":
			printHistory()
			break

		case "ArrowLeft":
			game.move = max(game.move-1, 0)
			break

		case "ArrowRight":
			game.move = min(game.move+1, game.boardHistory.length-1)
			break

		case "ArrowUp":
			game.move = 0
			break

		case "ArrowDown":
			game.move = game.boardHistory.length - 1
			break
	}
}

class Bot extends Chess {
	constructor() {

	}
}

class Fortuna extends Bot {
	constructor() {

	}
}

class Parallax extends Bot {
	constructor() {
		
	}
}

class Astranaught extends Bot {
	constructor() {
		
	}
}

class Lazaward extends Bot {
	constructor() {
		
	}
}

class AlephInfinity extends Bot {
	constructor() {
		
	}
}

